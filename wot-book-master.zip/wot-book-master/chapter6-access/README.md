# Code Examples 
Code examples from the [Building the Web of Things](http://manning.com/guinard/?a_aid=wot&a_bid=16f48f14) book.

