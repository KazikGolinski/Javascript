var ops = require('./lib/operations'); 	//#A

console.log(ops.add(42, 42));
console.log(ops.mul(42, 42));
console.log(ops.sub(42, 42));

//#A Imports the operations.js module