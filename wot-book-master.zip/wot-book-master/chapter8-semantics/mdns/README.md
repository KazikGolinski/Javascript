# mDNS Example for your Pi
Code sample from the [Building the Web of Things](http://manning.com/guinard/?a_aid=wot&a_bid=16f48f14) book built using the [node_mdns](https://github.com/agnat/node_mdns) module.

## Prerequisite

To run this sample on your Raspberry Pi or embedded Linux device you first need to install the


