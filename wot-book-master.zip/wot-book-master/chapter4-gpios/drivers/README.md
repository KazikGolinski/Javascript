# BCM2835 Library for DHT22
This library is provided here to help the reader but you can find the orginal sources and the latest version on the [BCM2835 C Library Website](http://www.airspayce.com/mikem/bcm2835/index.html)
